import TicTacToe from './components/TicTacToe';

function App() {
  return <TicTacToe />;
}

export default App;
