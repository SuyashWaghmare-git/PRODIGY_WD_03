import { useState, useEffect } from 'react';
import { GameState, GameMode, Difficulty, Player } from '../types/game';
import { checkWinner, getBestMove, getRandomMove } from '../utils/gameLogic';
import { X, Circle, RotateCcw } from 'lucide-react';

interface TicTacToeProps {
  initialMode?: GameMode;
  initialDifficulty?: Difficulty;
}

export default function TicTacToe({ initialMode = 'pvp', initialDifficulty = 'hard' }: TicTacToeProps) {
  const [gameState, setGameState] = useState<GameState>({
    board: Array(9).fill(null),
    currentPlayer: 'X',
    winner: null,
    winningLine: null,
    gameMode: initialMode,
    difficulty: initialDifficulty,
  });

  const [isThinking, setIsThinking] = useState(false);

  useEffect(() => {
    if (
      gameState.gameMode === 'ai' &&
      gameState.currentPlayer === 'O' &&
      !gameState.winner &&
      !isThinking
    ) {
      setIsThinking(true);
      const timer = setTimeout(() => {
        makeAIMove();
        setIsThinking(false);
      }, 500);
      return () => clearTimeout(timer);
    }
  }, [gameState.currentPlayer, gameState.winner, gameState.gameMode]);

  const makeAIMove = () => {
    const move =
      gameState.difficulty === 'hard'
        ? getBestMove([...gameState.board], 'O', 'X')
        : getRandomMove([...gameState.board]);

    if (move !== -1) {
      handleCellClick(move);
    }
  };

  const handleCellClick = (index: number) => {
    if (gameState.board[index] || gameState.winner || isThinking) return;

    const newBoard = [...gameState.board];
    newBoard[index] = gameState.currentPlayer;

    const { winner, winningLine } = checkWinner(newBoard);

    setGameState({
      ...gameState,
      board: newBoard,
      currentPlayer: gameState.currentPlayer === 'X' ? 'O' : 'X',
      winner,
      winningLine,
    });
  };

  const resetGame = () => {
    setGameState({
      ...gameState,
      board: Array(9).fill(null),
      currentPlayer: 'X',
      winner: null,
      winningLine: null,
    });
    setIsThinking(false);
  };

  const changeMode = (mode: GameMode) => {
    setGameState({
      board: Array(9).fill(null),
      currentPlayer: 'X',
      winner: null,
      winningLine: null,
      gameMode: mode,
      difficulty: gameState.difficulty,
    });
    setIsThinking(false);
  };

  const changeDifficulty = (difficulty: Difficulty) => {
    setGameState({
      ...gameState,
      difficulty,
    });
  };

  const renderCell = (index: number) => {
    const value = gameState.board[index];
    const isWinningCell = gameState.winningLine?.includes(index);

    return (
      <button
        key={index}
        onClick={() => handleCellClick(index)}
        className={`
          relative aspect-square w-full
          bg-gradient-to-br from-amber-50 to-yellow-100
          border-4 border-gray-300
          rounded-lg
          transition-all duration-300
          hover:scale-105 hover:border-gray-400
          active:scale-95
          ${isWinningCell ? 'animate-pulse border-green-500' : ''}
          ${value ? 'cursor-not-allowed' : 'cursor-pointer'}
        `}
        disabled={!!value || !!gameState.winner || isThinking}
      >
        <div className="absolute inset-0 flex items-center justify-center">
          {value === 'X' && (
            <div className="relative animate-scaleIn">
              <X
                size={80}
                strokeWidth={8}
                className="text-green-600"
              />
            </div>
          )}
          {value === 'O' && (
            <div className="relative animate-scaleIn">
              <Circle
                size={80}
                strokeWidth={8}
                className="text-red-600"
              />
            </div>
          )}
        </div>
      </button>
    );
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-yellow-400 via-orange-300 to-amber-400 flex items-center justify-center p-4">
      <div className="max-w-2xl w-full">
        <div className="text-center mb-8">
          <h1 className="text-6xl font-bold text-gray-800 mb-2 drop-shadow-lg">
            Tic-Tac-Toe
          </h1>
        </div>

        <div className="bg-white/80 backdrop-blur-sm rounded-3xl shadow-2xl p-8 mb-6">
          <div className="flex gap-4 mb-6 flex-wrap justify-center">
            <button
              onClick={() => changeMode('pvp')}
              className={`px-6 py-3 rounded-xl font-semibold transition-all ${
                gameState.gameMode === 'pvp'
                  ? 'bg-blue-600 text-white shadow-lg scale-105'
                  : 'bg-gray-200 text-gray-700 hover:bg-gray-300'
              }`}
            >
              Player vs Player
            </button>
            <button
              onClick={() => changeMode('ai')}
              className={`px-6 py-3 rounded-xl font-semibold transition-all ${
                gameState.gameMode === 'ai'
                  ? 'bg-blue-600 text-white shadow-lg scale-105'
                  : 'bg-gray-200 text-gray-700 hover:bg-gray-300'
              }`}
            >
              Player vs AI
            </button>
          </div>

          {gameState.gameMode === 'ai' && (
            <div className="flex gap-4 mb-6 flex-wrap justify-center">
              <button
                onClick={() => changeDifficulty('easy')}
                className={`px-6 py-3 rounded-xl font-semibold transition-all ${
                  gameState.difficulty === 'easy'
                    ? 'bg-green-600 text-white shadow-lg scale-105'
                    : 'bg-gray-200 text-gray-700 hover:bg-gray-300'
                }`}
              >
                Easy
              </button>
              <button
                onClick={() => changeDifficulty('hard')}
                className={`px-6 py-3 rounded-xl font-semibold transition-all ${
                  gameState.difficulty === 'hard'
                    ? 'bg-red-600 text-white shadow-lg scale-105'
                    : 'bg-gray-200 text-gray-700 hover:bg-gray-300'
                }`}
              >
                Hard
              </button>
            </div>
          )}

          <div className="relative grid grid-cols-3 gap-4 mb-6 p-6 bg-gradient-to-br from-gray-100 to-gray-200 rounded-2xl">
            {gameState.board.map((_, index) => renderCell(index))}
          </div>

          <div className="text-center space-y-4">
            {!gameState.winner && (
              <p className="text-2xl font-semibold text-gray-800">
                {isThinking ? (
                  <span className="animate-pulse">AI is thinking...</span>
                ) : (
                  <>
                    Current Player:{' '}
                    <span
                      className={`${
                        gameState.currentPlayer === 'X' ? 'text-green-600' : 'text-red-600'
                      }`}
                    >
                      {gameState.currentPlayer}
                    </span>
                  </>
                )}
              </p>
            )}

            {gameState.winner && (
              <div className="animate-bounceIn">
                <p className="text-3xl font-bold mb-4">
                  {gameState.winner === 'draw' ? (
                    <span className="text-gray-700">It's a Draw!</span>
                  ) : (
                    <span
                      className={`${
                        gameState.winner === 'X' ? 'text-green-600' : 'text-red-600'
                      }`}
                    >
                      Player {gameState.winner} Wins!
                    </span>
                  )}
                </p>
              </div>
            )}

            <button
              onClick={resetGame}
              className="inline-flex items-center gap-2 px-8 py-4 bg-gradient-to-r from-blue-600 to-blue-700 text-white font-semibold rounded-xl shadow-lg hover:shadow-xl hover:scale-105 active:scale-95 transition-all"
            >
              <RotateCcw size={24} />
              New Game
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}
