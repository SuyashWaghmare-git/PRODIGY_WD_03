export type Player = 'X' | 'O';
export type CellValue = Player | null;
export type Board = CellValue[];
export type GameMode = 'pvp' | 'ai';
export type Difficulty = 'easy' | 'hard';

export interface GameState {
  board: Board;
  currentPlayer: Player;
  winner: Player | 'draw' | null;
  winningLine: number[] | null;
  gameMode: GameMode;
  difficulty: Difficulty;
}
